const express = require('express');
const router = express.Router();
 // Hyperledger Bridge
 const { FileSystemWallet, Gateway } = require('fabric-network')
 const fs = require('fs')
 const path = require('path')
 const ccpPath = path.resolve(__dirname, '..', '..', 'basic-network', 'connection.json')
const ccpJSON = fs.readFileSync(ccpPath, 'utf8')
const ccp = JSON.parse(ccpJSON)

// Qeury all cars page
router.get('/car', async  function (req, res)  {
    // Create a new file system based wallet for managing identities.
    console.log(process.cwd())
    const walletPath = path.join(process.cwd(), 'wallet')
    const wallet = new FileSystemWallet(walletPath)
    console.log(`Wallet path: ${walletPath}`)

    // Check to see if we've already enrolled the user.
    const userExists = await wallet.exists('user1')
    if (!userExists) {
        console.log('An identity for the user "user1" does not exist in the wallet')
        console.log('Run the registerUser.js application before retrying')
        return
    }

    // Create a new gateway for connecting to our peer node.
    const gateway = new Gateway()
    await gateway.connect(ccp, { wallet, identity: 'user1', discovery: { enabled: false } })

    // Get the network (channel) our contract is deployed to.
    const network = await gateway.getNetwork('mychannel')

    // Get the contract from the network.
    const contract = network.getContract('fabcar')

    // Evaluate the specified transaction.
    const result = await contract.evaluateTransaction('queryAllCars')
    console.log(`Transaction has been evaluated, result is: ${result.toString()}`)
    // res..json({response: result.toString()}) 
    res.json(result.toString())
})

// Query car handle
// localhost:8080/api/query/:carno
router.get('/car/:carno', async function (req, res) {
    try {
        // var carno = req.query.carno
        var carno = req.param('carno')
        console.log(carno)

        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), 'wallet')
        const wallet = new FileSystemWallet(walletPath)
        console.log(`Wallet path: ${walletPath}`)

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user1')
        if (!userExists) {
            console.log('An identity for the user "user1" does not exist in the wallet')
            console.log('Run the registerUser.js application before retrying')
            return
        }
        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway()
        await gateway.connect(ccp, { wallet, identity: 'user1', discovery: { enabled: false } })

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel')

        // Get the contract from the network.
        const contract = network.getContract('fabcar')

        // Evaluate the specified transaction.
        const result = await contract.evaluateTransaction('queryCar', carno)

        console.log(`Transaction has been evaluated, result is: ${result.toString()}`)
        res.status(200).json({response: result.toString()})      
    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`)
        res.status(400).json(error)
    }   
})

// Create car handle
router.post('/car', async function (req, res) {
    try {
        var carno = req.body.carno
        var colour = req.body.colour
        var make = req.body.make
        var model = req.body.model
        var owner = req.body.owner
        console.log(carno, colour, make, model,owner) 

        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), 'wallet')
        const wallet = new FileSystemWallet(walletPath)
        console.log(`Wallet path: ${walletPath}`)

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user1')
        if (!userExists) {
            console.log('An identity for the user "user1" does not exist in the wallet')
            console.log('Run the registerUser.js application before retrying')
            return;
        }
        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway()
        await gateway.connect(ccp, { wallet, identity: 'user1', discovery: { enabled: false } });

        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel')

        // Get the contract from the network.
        const contract = network.getContract('fabcar')

        // Submit the specified transaction.
        // console.log(carno, make, model, colour, owner)
        await contract.submitTransaction('createCar', carno, make, model, colour, owner)
        console.log('Transaction has been submitted')

        // Disconnect from the gateway.
        await gateway.disconnect()

        res.status(200).json({response: 'Transaction has been submitted'})
    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`)
        res.status(400).json(error)
    }   
})

// Change car owner handle
router.put('/car/:carno', async function (req, res) {
    try {
        // console.log(req)
        var carno = req.param('carno')
        var owner = req.body.owner
        console.log(carno, owner)
        // Create a new file system based wallet for managing identities.
        const walletPath = path.join(process.cwd(), 'wallet')
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        // Check to see if we've already enrolled the user.
        const userExists = await wallet.exists('user1');
        if (!userExists) {
            console.log('An identity for the user "user1" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        // Create a new gateway for connecting to our peer node.
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'user1', discovery: { enabled: false } }); 
        
        // Get the network (channel) our contract is deployed to.
        const network = await gateway.getNetwork('mychannel');

        // Get the contract from the network.
        const contract = network.getContract('fabcar');

        // Submit the specified transaction.
        await contract.submitTransaction('changeCarOwner', carno, owner);
        console.log('Transaction has been submitted');

        // Disconnect from the gateway.
        await gateway.disconnect();
        res.status(200).json({response: 'Transaction has been submitted'});
    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        res.status(400).json(error);
    }   
})

module.exports = router;