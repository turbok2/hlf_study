// Express Setup
const express = require('express')
const app = express()
var bodyParser = require('body-parser')
const PORT = 3000


 // Hyperledger Bridge
const { FileSystemWallet, Gateway } = require('fabric-network')
const fs = require('fs')
const path = require('path')
const ccpPath = path.resolve(__dirname, '..', '..', 'basic-network', 'connection.json')
const ccpJSON = fs.readFileSync(ccpPath, 'utf8')
const ccp = JSON.parse(ccpJSON)

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }))
// app.use('/', require('./index'));

app.use('/api', require('./api_index'));

app.use(express.static('public'))
app.get('/', function(req, res){
    res.sendFile(__dirname + '/public/index.html');
    });

// server start
app.listen(PORT, function() {
    console.log(`Running on http://localhost:${PORT}`)
})


